#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist


rospy.init_node('ex_3_1')
my_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
my_move = Twist()

my_move.linear.x = 1
my_move.angular.z = 0.2

rate = rospy.Rate(2)

while not rospy.is_shutdown():
    my_pub.publish(my_move)
    rate.sleep()


