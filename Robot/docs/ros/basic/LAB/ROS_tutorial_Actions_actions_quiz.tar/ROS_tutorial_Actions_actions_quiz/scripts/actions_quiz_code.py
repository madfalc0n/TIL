#! /usr/bin/env python

import rospy

from actions_quiz.msg import CustomActionMsgFeedback, CustomActionMsgAction, CustomActionMsgResult
import actionlib
from std_msgs.msg import Empty

class drone(object):
    pass
    def __init__(self):
        self._as = actionlib.SimpleActionServer('action_custom_msg_as', CustomActionMsgAction, self.callback, False)
        self._as.start()
        self._takeoff = rospy.Publisher('/drone/takeoff',Empty,queue_size=1)
        self._land = rospy.Publisher('/drone/land',Empty,queue_size=1)
        self._empty_msg = Empty()
        self._feedback = CustomActionMsgFeedback()
    
    def com(self,input):
        r = rospy.Rate(1)
        rospy.loginfo(f'INPUT : {input}')
        
        if input == 'TAKEOFF':
            self._feedback.feedback = 'taking off'
            self._as.publish_feedback(self._feedback)
            for _ in range(3):
                self._takeoff.publish(self._empty_msg)
                r.sleep()

        elif input == 'LAND':
            self._feedback.feedback = 'landing'
            self._as.publish_feedback(self._feedback)
            for _ in range(3):
                self._land.publish(self._empty_msg)
                r.sleep()
        
        rospy.loginfo(f'{input} complete!')

    def callback(self, goal):
        self.input = goal.goal
        self.success = True
        
        self.com(self.input)



rospy.init_node('actions_quiz')
drone()
rospy.spin()