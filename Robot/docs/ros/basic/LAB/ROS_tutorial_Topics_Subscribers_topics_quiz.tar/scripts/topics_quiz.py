#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

def callback(msg): 
    range_list = msg.ranges
    print(range_list[360],range_list[30])

    move.linear.x = 0.2
    if range_list[360] <= 1.0 or range_list[30] <= 0.3:
        move.angular.z = -0.5
    else:
        move.angular.z = 0
    pub.publish(move)

rospy.init_node('topics_quiz_node')
pub = rospy.Publisher('/cmd_vel',Twist, queue_size=1)
sub = rospy.Subscriber('/kobuki/laser/scan', LaserScan, callback)
move = Twist() 

rospy.spin()
