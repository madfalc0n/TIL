#! /usr/bin/env python

import rospy
from services_quiz.srv import BB8CustomServiceMessage, BB8CustomServiceMessageResponse
from geometry_msgs.msg import Twist
import time



    
def rotate_angle():
    PI = 3.1415926535897
    speed = 30
    angle = 90
    angular_speed = speed*2*PI/360
    relative_angle = angle*2*PI/360

    my_move.linear.x = 0
    my_move.linear.y = 0
    my_move.linear.z = 0
    my_move.angular.x = 0
    my_move.angular.y = 0
    my_move.angular.z = 0

    my_move.angular.z = abs(angular_speed)

    # Setting the current time for distance calculus
    t0 = rospy.Time.now().to_sec()
    current_angle = 0
    while(current_angle <= relative_angle):
        my_pub.publish(my_move)
        t1 = rospy.Time.now().to_sec()
        current_angle = angular_speed*(t1-t0)

    my_move.angular.z = 0
    my_pub.publish(my_move)

def move(t):
    my_move.linear.x = 1
    my_pub.publish(my_move)

    time.sleep(t)
    
    my_move.linear.x = 0
    my_pub.publish(my_move)
    time.sleep(2)


def my_callback(request):
    my_response = BB8CustomServiceMessageResponse()
    # print(f'side value : {request.side}')
    # print(f'repetitions value : {request.repetitions}')

    s_v = float(request.side)
    r_v = int(request.repetitions)
    for _ in range(r_v):
        for i in range(4):
            move(s_v)
            rotate_angle()
        
    


    my_response.success = True
    return my_response


rospy.loginfo('initializing custom')
rospy.init_node('move_bb8_in_square_custom_server')
my_service = rospy.Service('/move_bb8_in_square_custom' , BB8CustomServiceMessage, my_callback)
my_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
my_move = Twist()

rospy.spin()
