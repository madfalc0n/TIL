#! /usr/bin/env python

import rospy
from services_quiz.srv import BB8CustomServiceMessage, BB8CustomServiceMessageRequest


rospy.init_node('move_bb8_in_square_custom_client')
rospy.wait_for_service('/move_bb8_in_square_custom')

client = rospy.ServiceProxy('/move_bb8_in_square_custom', BB8CustomServiceMessage)
client_request_obj = BB8CustomServiceMessageRequest()


side_val = 1.8
repetitions_val = 1 
client_request_obj.side = side_val
client_request_obj.repetitions = repetitions_val

rospy.loginfo(f'Sending value - side val : {side_val} , repetitions val : {repetitions_val}')
result = client(client_request_obj)
print(result)


