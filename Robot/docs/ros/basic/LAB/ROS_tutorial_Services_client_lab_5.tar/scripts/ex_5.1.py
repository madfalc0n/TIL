#! /usr/bin/env python

import rospy
# # Import the service message used by the service /trajectory_by_name
# from trajectory_by_name_srv.srv import TrajByName, TrajByNameRequest
from iri_wam_reproduce_trajectory.srv import ExecTraj, ExecTrajRequest
import sys
import rospkg

# Initialise a ROS node with the name service_client
rospy.init_node('madfalcon_robot_client')

# Wait for the service client /trajectory_by_name to be running
rospy.wait_for_service('/execute_trajectory')

execute_traj_by_name_service = rospy.ServiceProxy('/execute_trajectory', ExecTraj)
execute_traj_by_name_object = ExecTrajRequest()

rospack = rospkg.RosPack()
trajectory_file_path = rospack.get_path('iri_wam_reproduce_trajectory') + "/config/get_food.txt"
print(f'File path : {trajectory_file_path}')

execute_traj_by_name_object.file = trajectory_file_path # Fill the variable file of this object with the desired file path
result = execute_traj_by_name_service(execute_traj_by_name_object) # Send through the connection the path to the trajectory file to be executed

print(result) # Print the result type ExecTrajResponse



