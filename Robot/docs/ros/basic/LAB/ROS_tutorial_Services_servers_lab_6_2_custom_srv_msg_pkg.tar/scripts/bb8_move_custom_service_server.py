#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from lab_6_custom_srv_msg_pkg.srv import MyCustomServiceMessage, MyCustomServiceMessageResponse # you import the service message python classes 

def mycallback(request):
    print("Request Data==> duration="+str(request.duration))
    my_response = MyCustomServiceMessageResponse()
    my_duration = int(request.duration)
    rate = rospy.Rate(1)
    while my_duration > -1:
        print(f"current duration : {my_duration}")
        move_circle.linear.x = 0.2
        move_circle.angular.z = 0.2
        my_pub.publish(move_circle)
        my_duration -= 1
        rate.sleep()

    move_circle.linear.x = 0.0
    move_circle.angular.z = 0.0
    my_pub.publish(move_circle)

    my_response.success = True    
    return  my_response # the service Response class, in this case MyCustomServiceMessageResponse


rospy.init_node('madfalcon_bb8_move_server')
my_service = rospy.Service('/move_bb8_in_circle_custom', MyCustomServiceMessage, mycallback)
my_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
move_circle = Twist()
rospy.loginfo("Service /move_bb8_in_circle Ready")
rospy.spin() # mantain the service open.