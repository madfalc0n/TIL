#! /usr/bin/env python

import rospy
from lab_6_custom_srv_msg_pkg.srv import MyCustomServiceMessage, MyCustomServiceMessageRequest

rospy.init_node('madfalcon_bb8_move_client')
rospy.wait_for_service('/move_bb8_in_circle_custom')


move_bb8_in_circle_service_client = rospy.ServiceProxy('/move_bb8_in_circle_custom', MyCustomServiceMessage) # Create the connection to the service
my_request_obj = MyCustomServiceMessageRequest()

duration_value = 10
my_request_obj.duration = duration_value

rospy.loginfo(f'Sending durations : {duration_value}')
result = move_bb8_in_circle_service_client(my_request_obj) # Send through the connection the path to the trajectory file to be executed
print(result) # Print the result given by the service called