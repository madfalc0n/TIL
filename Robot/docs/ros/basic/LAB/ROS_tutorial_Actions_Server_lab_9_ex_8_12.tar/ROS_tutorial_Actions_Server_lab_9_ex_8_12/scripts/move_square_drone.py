#! /usr/bin/env python
import rospy

import actionlib
from actionlib.msg import TestFeedback, TestResult, TestAction
from std_msgs.msg import Empty
from geometry_msgs.msg import Twist
import time

class TestClass(object):
    _feedback = TestFeedback()
    _result = TestResult()

    def __init__(self):
        self._as = actionlib.SimpleActionServer('move_drone_square', TestAction, self.goal_callback, False)
        self._my_pub = rospy.Publisher('/cmd_vel', Twist, queue_size = 1)
        self._my_move = Twist()
        self._as.start()

    def stop(self):
        rospy.loginfo('stoping........')
        self._my_move.linear.x = 0
        self._my_move.angular.z = 0
        self._my_pub.publish(self._my_move)

    def turn(self):
        rospy.loginfo('turning........')
        self._my_move.linear.x = 0
        self._my_move.angular.z = 1
        self._my_pub.publish(self._my_move)

    def move(self):
        rospy.loginfo('moving........')
        self._my_move.linear.x = 1
        self._my_move.angular.z = 0
        self._my_pub.publish(self._my_move)

    def goal_callback(self, goal):
        self.success = True
        self._feedback.feedback = 0
        moveside = goal.goal
        turnside = 1.8
        r = rospy.Rate(1)

        rospy.loginfo('takeoff drone')
        empty_msg = Empty()
        takeoff = rospy.Publisher('/drone/takeoff',Empty, queue_size=1)
        for _ in range(3):
            takeoff.publish(empty_msg)
            time.sleep(1)
            # r.sleep()

        
        time.sleep(5)


        for i in range(1,5):
            self.move()
            time.sleep(moveside)
            self.turn()
            time.sleep(1.8)

            if self._as.is_preempt_requested():
                rospy.loginfo('The goal has been cancelled/preempted')
                # the following line, sets the client in preempted state (goal cancelled)
                self._as.set_preempted()
                self.success = False
                # we end the calculation of the Fibonacci sequence
                break
            self._feedback.feedback = i
            self._as.publish_feedback(self._feedback)
        
        self.stop()
        if self.success:
            self._result.result = self._feedback.feedback
            rospy.loginfo('Succeeded moving sqaure drone')
            self._as.set_succeeded(self._result)

        rospy.loginfo('Landing drone')
        land = rospy.Publisher('/drone/land',Empty, queue_size=1)
        for _ in range(3):
            land.publish(empty_msg)
            time.sleep(1)
            # r.sleep()
        
      
if __name__ == '__main__':
    rospy.init_node('moving_drone_square')
    rospy.loginfo('initializing drone server')
    TestClass()
    rospy.spin()